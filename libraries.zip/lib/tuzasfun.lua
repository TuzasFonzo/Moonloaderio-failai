-- tuzasfun.lua
local tuzasfun = {}

local ffi = require 'ffi'

local memory = require 'memory'

local keyStates = {}

function tuzasfun.isKeyJustReleased(keyCode)
    local state = isKeyDown(keyCode)
    local prevState = keyStates[keyCode]
    keyStates[keyCode] = state
    return not state and prevState
end

function tuzasfun.SAMPGetActorHealthByID(id)
    local samp = getModuleHandle('samp.dll')
    local samp_info = samp + 0x26EB94
    samp_info = readMemory(samp_info, 4, false)

    local samp_ppools = samp_info + 0x3DE
    samp_ppools = readMemory(samp_ppools, 4, false)
    local samp_ppool_player = samp_ppools + 0x4
    samp_ppool_player = readMemory(samp_ppool_player, 4, false)
    id = id * 0x4
    id = id + 0x1F8A
    SAMP_REMOTEPLAYER_OFFSET = samp_ppool_player + id
    SAMP_REMOTEPLAYER_OFFSET = readMemory(samp_ppool_player, 4, false)
    if SAMP_REMOTEPLAYER_OFFSET > 0 then
        SAMP_REMOTEPLAYERDATA_OFFSET = SAMP_REMOTEPLAYER_OFFSET + 0x10
        SAMP_REMOTEPLAYERDATA_OFFSET = readMemory(SAMP_REMOTEPLAYERDATA_OFFSET, 4, false)
        if SAMP_REMOTEPLAYERDATA_OFFSET > 0 then
            SAMP_REMOTEPLAYERDATA_HEATLH_OFFSET = SAMP_REMOTEPLAYERDATA_OFFSET + 0x1B0
            SAMP_REMOTEPLAYERDATA_HEATLH_OFFSET = readMemory(SAMP_REMOTEPLAYERDATA_HEATLH_OFFSET, 4, false)
            if not SAMP_REMOTEPLAYERDATA_HEATLH_OFFSET < 0 then
                dats = SAMP_REMOTEPLAYERDATA_HEATLH_OFFSET
                return dats
            else
                return false
            end
        else
            return false
        end
    else
        return false
    end
end


function tuzasfun.IsPlayerConnected(id)
    local samp = getModuleHandle('samp.dll')
    local samp_info = samp + 0x26EB94
    samp_info = readMemory(samp_info, 4, false)

    local samp_ppools = samp_info + 0x3DE
    samp_ppools = readMemory(samp_ppools, 4, false)
    local samp_ppool_player = samp_ppools + 0x4
    samp_ppool_player = readMemory(samp_ppool_player, 4, false)

    if (1003 < id) then
        return 0;
    end
    status = memory.getuint32(samp_ppool_player + 0x2a + id * 4, false)
    if status > 0 then
        return true
    else
        return false
    end
end


function tuzasfun.GetPlayerNickname(id)
    local samp = getModuleHandle('samp.dll')
    local samp_info = samp + 0x26EB94
    samp_info = readMemory(samp_info, 4, false)

    local samp_ppools = samp_info + 0x3DE
    samp_ppools = readMemory(samp_ppools, 4, false)
    local samp_ppool_player = samp_ppools + 0x4
    samp_ppool_player = readMemory(samp_ppool_player, 4, false)
    if id == memory.getuint16(samp_ppool_player + 4, false) then
        if memory.getuint32(samp_ppool_player + 0x1e, false) > 0xf then
            return readString(memory.getint32(samp_ppool_player + 10, false), 32, false)
        end
        return readString(samp_ppool_player + 10, 32, false)
    end

    local addr = memory.getint32(samp_ppool_player + 0x1f8a + id * 4, false)
    if id < 0x3ed and addr ~= 0 then
        if memory.getuint32(addr + 0x2c, false) > 0xf then
            return readString(memory.getint32(addr + 0x18, false), 32, false)
        end
        return readString(addr + 0x18, 32, false)
    end

    return ""
end


function tuzasfun.UpdateScoreBoard() 
    local samp = getModuleHandle('samp.dll')
    local samp_scoreboard_info = samp + 0x26EB94
    samp_scoreboard_info = readMemory(samp_scoreboard_info,4,false)
    local samp_update_scoreboard_info = samp + 0x8F10
    local func = ffi.cast('void (__fastcall *)(void *)', samp_update_scoreboard_info)
    if func ~= 0 then
        local p1 = ffi.cast('void *', samp_scoreboard_info)
        func(p1)
    end

end

function tuzasfun.UpdateScoreBoardList()
    local samp = getModuleHandle('samp.dll')
    local samp_scoreboard_info = samp + 0x26EB4C
    samp_scoreboard_info = readMemory(samp_scoreboard_info,4,false)
    local samp_update_scoreboard_info = samp + 0x6ED30
    local func = ffi.cast('void (__fastcall *)(void *)', samp_update_scoreboard_info)
    if func ~= 0 then
        local p1 = ffi.cast('void *', samp_scoreboard_info)
        func(p1)
    end

end


function tuzasfun.isSampAvailable()
    samp = readMemory(0xC8D4C0, 4, false)
    if samp == 9 then
        return true
    else
        return false
    end
end


function tuzasfun.SAMPIs3dTextDefined(id)
    local samp_dll = getModuleHandle('samp.dll')
    samp_dll = samp_dll + 0x26EB94
    samp_dll = readMemory(samp_dll, 4, false)
    samp_dll = samp_dll + 0x3DE
    samp_dll = readMemory(samp_dll, 4, false)
    samp_dll = samp_dll + 0x18
    samp_dll = readMemory(samp_dll, 4, false)
    id = 0x4 * id
    samp_dll = samp_dll + id
    -- samp_dll = readMemory(samp_dll, 4, false)
    local SAMP_3D_TEXT_DEFINED_OFFSET = samp_dll + 0xE800
    local SAMP_3D_TEXT_DEFINED = readMemory(SAMP_3D_TEXT_DEFINED_OFFSET, 4, false)
    if SAMP_3D_TEXT_DEFINED > 0 then
        return true
    else
        return false
    end
end

function tuzasfun.SAMPGet3dTextInfoByID(id)
    local samp_dll = getModuleHandle('samp.dll') -- GET SAMP.DL MEMORY
    SAMP_INFO = samp_dll + 0x26EB94 -- SAMP_INFO_OFFSET
    SAMP_INFO = readMemory(SAMP_INFO, 4, false)
    SAMP_POOLS = SAMP_INFO + 0x3DE -- SAMP_POOLS_OFFSET
    SAMP_POOLS = readMemory(SAMP_POOLS, 4, false)
    SAMP_3D_TEXT_POOL = SAMP_POOLS + 0x18
    SAMP_3D_TEXT_POOL = readMemory(SAMP_3D_TEXT_POOL, 4, false)
    SAMP_3D_TEXT_STRUCT = id * 0x1D -- SAMP_3D_TEXT_STRUCT_OFFSET
    SAMP_3D_TEXT_STRUCT = SAMP_3D_TEXT_STRUCT + SAMP_3D_TEXT_POOL
    SECURITY_CHECK = readMemory(SAMP_3D_TEXT_STRUCT, 1, false)
    if SECURITY_CHECK > 0 then
        local SAMP_3D_TEXT_COLOR_OFFSET = SAMP_3D_TEXT_STRUCT + 0x4
        local SAMP_3D_TEXT_POSITION_X_OFFSET = SAMP_3D_TEXT_STRUCT + 0x8
        local SAMP_3D_TEXT_POSITION_Y_OFFSET = SAMP_3D_TEXT_STRUCT + 0xC
        local SAMP_3D_TEXT_POSITION_Z_OFFSET = SAMP_3D_TEXT_STRUCT + 0x10
        local SAMP_3D_TEXT_VIEW_DISTANCE_OFFSET = SAMP_3D_TEXT_STRUCT + 0x14
        local SAMP_3D_TEXT_THROUGH_WALLS_OFFSET = SAMP_3D_TEXT_STRUCT + 0x18
        local SAMP_3D_ATTACHED_TO_PLAYER_OFFSET = SAMP_3D_TEXT_STRUCT + 0x19
        local SAMP_3D_ATTACHED_TO_VEHICLE_OFFSET = SAMP_3D_TEXT_STRUCT + 0x1B

        local SAMP_3D_TEXT_TEXT = readMemory(SAMP_3D_TEXT_STRUCT, 4, false)
        if SAMP_3D_TEXT_TEXT then
            SAMP_3D_TEXT_TEXT = SAMP_3D_TEXT_TEXT + 0x0
            local SAMP_3D_TEXT_COLOR = readMemory(SAMP_3D_TEXT_COLOR_OFFSET, 4, false)
            local SAMP_3D_TEXT_POSITION_X = readMemory(SAMP_3D_TEXT_POSITION_X_OFFSET, 4, false)
            local SAMP_3D_TEXT_POSITION_Y = readMemory(SAMP_3D_TEXT_POSITION_Y_OFFSET, 4, false)
            local SAMP_3D_TEXT_POSITION_Z = readMemory(SAMP_3D_TEXT_POSITION_Z_OFFSET, 4, false)
            local SAMP_3D_TEXT_VIEW_DISTANCE = readMemory(SAMP_3D_TEXT_VIEW_DISTANCE_OFFSET, 4, false)
            local SAMP_3D_TEXT_THROUGH_WALLS = readMemory(SAMP_3D_TEXT_THROUGH_WALLS_OFFSET, 4, false)
            local SAMP_3D_ATTACHED_TO_PLAYER = readMemory(SAMP_3D_ATTACHED_TO_PLAYER_OFFSET, 4, false)
            local SAMP_3D_ATTACHED_TO_VEHICLE = readMemory(SAMP_3D_ATTACHED_TO_VEHICLE_OFFSET, 4, false)
            return readString(SAMP_3D_TEXT_TEXT, 1024, 'utf-8'), SAMP_3D_TEXT_COLOR, SAMP_3D_TEXT_POSITION_X,
                SAMP_3D_TEXT_POSITION_Y, SAMP_3D_TEXT_POSITION_Z, SAMP_3D_TEXT_VIEW_DISTANCE,
                SAMP_3D_TEXT_THROUGH_WALLS, SAMP_3D_ATTACHED_TO_PLAYER, SAMP_3D_ATTACHED_TO_VEHICLE
        else
            return false
        end
    end
end



function tuzasfun.readFloat(address, littleEndian)
    if littleEndian == nil then
        littleEndian = true
    end
    local bytes = readMemory(address, 4, false)
    local sign = 1
    local mantissa = bytes:byte(littleEndian and 4 or 1) % 128
    for i = 3, 1, -1 do
        mantissa = mantissa * 256 + bytes:byte(littleEndian and i or 5 - i)
    end
    if bytes:byte(4) > 127 then
        sign = -1
    end
    local exponent = (bytes:byte(4) % 128) * 2 + math.floor(bytes:byte(littleEndian and 3 or 2) / 128)
    if exponent == 0 then
        if mantissa == 0 then
            return 0.0
        else
            return sign * math.ldexp(mantissa / 8388608, -126)
        end
    elseif exponent == 255 then
        if mantissa == 0 then
            return sign / 0.0
        else
            return 0.0 / 0.0
        end
    end
    return sign * math.ldexp(1 + mantissa / 8388608, exponent - 127)
end

function tuzasfun.sampProcessChatInput(text)
    local samp_dll = getModuleHandle('samp.dll')
    local SAMP_CHAT_INPUT_INFO_OFFSET = samp_dll + 0x26EB84
    local pChatInput = readMemory(SAMP_CHAT_INPUT_INFO_OFFSET, 4, false)
    local pEditBox0 = pChatInput + 0x8
    local pEditBox = readMemory(pEditBox0, 4, false)
    local CDXUTEditBox = samp_dll + 0x85580
    local func = ffi.cast("void(__thiscall *)(void *, void*,  char *)", CDXUTEditBox)
    if func ~= 0 then
        local TextPointer = ffi.cast("void*", pEditBox)
        local EditBox = ffi.cast('void*', CDXUTEditBox)
        local c_str = ffi.new("char[?]", #text + 1)
        ffi.copy(c_str, text)
        func(TextPointer, c_str, EditBox)
    end
    local PROCESS_INPUT = samp_dll + 0x699D0
    local funcc = ffi.cast('void(__fastcall *)(void *)', PROCESS_INPUT)
    if funcc ~= 0 then
        local text_ptr = ffi.cast("void*", pChatInput)
        funcc(text_ptr)
    end
end


function tuzasfun.ChatMsg(text)
    --[[
            ChatMsg("{FFFF00}Hello!")
        --]]
    local samp10 = getModuleHandle('samp.dll')
    local samp_chat_info_offset = samp10 + 0x26EB80
    local ADDR_FUNC_ADD_MSG = samp10 + 0x68070
    local pChat = readMemory(samp_chat_info_offset, 4, false)
    local func = ffi.cast("void(__cdecl *)(void *, char *)", ADDR_FUNC_ADD_MSG)
    if func ~= 0 then
        local chatPointer = ffi.cast("void*", pChat)
        local c_str = ffi.new("char[?]", #text + 1)
        ffi.copy(c_str, text)
        func(chatPointer, c_str)
    end
    return true
end

local previous_message = ""
function tuzasfun.RegisterCommand()
    local samp_dll = getModuleHandle('samp.dll')
    local SAMP_INPUT_INFO_PTR = samp_dll + 0x26EB84
    SAMP_INPUT_INFO_PTR = readMemory(SAMP_INPUT_INFO_PTR, 4, false)
    local COMMAND_PTR = SAMP_INPUT_INFO_PTR + 0x14E5
    local command = readString(COMMAND_PTR, 1024, 'utf-8')
    if command ~= previous_message then
        previous_message = command
        return command
    end
end

function tuzasfun.desync(bool)
    local CHAR_PTR = getCharPointer(PLAYER_PED)
    CHAR_PTR = CHAR_PTR + 1328
    if bool == true then
        writeMemory(CHAR_PTR, 4, 50, false)
    else
        writeMemory(CHAR_PTR, 4, 1, false)
    end
end

function tuzasfun.ChatStringType()
    local samp_dll = getModuleHandle('samp.dll')
    samp_dll = samp_dll + 0x26EB80
    local chat_info = readMemory(samp_dll, 4, false)
    chat_info = chat_info + 0x132
    local chat_id = 99
    chat_id = chat_id * 0xFC
    chat_info = chat_info + chat_id
    chat_info = chat_info + 0xF0
    chat_type = readMemory(chat_info, 4, false)
    return chat_type
end

function tuzasfun.getChatString(chat_text, prefix_text, color, prefix_color)
    local samp_dll = getModuleHandle('samp.dll')
    samp_dll = samp_dll + 0x26EB80
    local chat_info = readMemory(samp_dll, 4, false)
    chat_info = chat_info + 0x132
    local chat_id = 99
    chat_id = chat_id * 0xFC
    chat_info = chat_info + chat_id

    local chat_text = chat_info + 0x20
    local prefix_text = chat_info + 0x4
    local color = readMemory(chat_info + 0xF4, 4, false)
    local prefix_color = readMemory(chat_info + 0xF8, 1, false)
    if not prefix_color then
        prefix_color = 0
    else
        prefix_color = readMemory(chat_info + 0xF8, 4, false)
    end
    return readString(chat_text, 1024, 'utf-8'), readString(prefix_text, 1024, 'utf-8'), color, prefix_color
end


function tuzasfun.GetTextDrawText(ID)
    local samp10 = getModuleHandle('samp.dll')
    samp10 = samp10 + 0x26EB94
    samp10 = readMemory(samp10, 4, false)
    samp10 = samp10 + 0x3DE
    samp10 = readMemory(samp10, 4, false)
    samp10 = samp10 + 0x1C
    samp10 = readMemory(samp10, 4, false)
    ID = ID * 0x4
    samp10 = samp10 + ID
    local samp9 = readMemory(samp10, 4, false)
    if samp9 then
        samp10 = samp10 + 0x2400
        samp10 = readMemory(samp10, 4, false)
        samp10 = samp10 + 0x0
        local text = readMemory(samp10, 4, false)
        return text
    else
        return false
    end
end

function tuzasfun.SetChatInputEnabled(bool)
    local SAMP_DLL = getModuleHandle('samp.dll')
    local SAMP_CHAT_INPUT_INFO_OFFSET = SAMP_DLL + 0x26EB84
    local SAMP_CHAT_INPUT_INFO_PTR = readMemory(SAMP_CHAT_INPUT_INFO_OFFSET, 4, false)
    if bool == true then
        SAMP_CHAT_INPUT_INFO_OFFSET = SAMP_DLL + 0x69480
    else
        SAMP_CHAT_INPUT_INFO_OFFSET = SAMP_DLL + 0x69580
        local func = ffi.cast('void(__fastcall*)(int)', SAMP_CHAT_INPUT_INFO_OFFSET)
        if func ~= 0 then
            local obj = ffi.cast('int', SAMP_CHAT_INPUT_INFO_PTR)
            func(obj)

        end
    end
end

function tuzasfun.enableDialog(bool)
    SAMP_DIALOG_INFO_PTR = getModuleHandle('samp.dll') + 0x26EB50
    SAMP_DIALOG_INFO_PTR = readMemory(SAMP_DIALOG_INFO_PTR, 4, false)
    SAMP_DIALOG_INFO_PTR = SAMP_DIALOG_INFO_PTR + 0x28
    memory.setint32(SAMP_DIALOG_INFO_PTR, bool and 1 or 0, false)
    sampToggleCursor(bool)
end

function tuzasfun.sampToggleCursor(bool)
    SAMP_MISC_INFO = 0x26EBAC
    SAMP_FUNC_TOGGLECURSOR = 0xA06F0
    SAMP_FUNC_CURSORUNLOCKACTORCAM = 0xA05D0
    samp10 = getModuleHandle('samp.dll')
    SAMP_MISC_INFO_PTR = memory.getint32(samp10 + SAMP_MISC_INFO)
    if type(bool) ~= 'boolean' then
        bool = false
    end
    local obj = ffi.cast('void**', SAMP_MISC_INFO_PTR)
    local show = ffi.cast('void (__thiscall*)(void*, int, bool)', samp10 + SAMP_FUNC_TOGGLECURSOR)
    show(obj, bool and 3 or 0, bool)
    if not bool then
        ffi.cast('void (__thiscall*)(void*)', samp10 + SAMP_FUNC_CURSORUNLOCKACTORCAM)(obj)
    end
end

function tuzasfun.SetDialogList(item)
    --[[
        0.3.7 - R5
        SetDialogList(5)
    ]]
    local samp10 = getModuleHandle('samp.dll')
    local samp_dialog_info_offset = samp10 + 0x26EB50
    samp_dialog_info_offset = readMemory(samp_dialog_info_offset, 4, false)
    local samp_dialog_list_box_offset = samp_dialog_info_offset + 0x20
    samp_dialog_list_box_offset = readMemory(samp_dialog_list_box_offset, 4, false)

    local samp_set_dialog_list_item_offset = samp10 + 0x8A9F0
    local setdialog = ffi.cast("void(__thiscall*)(void*, int)", samp_set_dialog_list_item_offset)
    if setdialog ~= 0 then
        local dialogPointer = ffi.cast("void*", samp_dialog_list_box_offset)
        local c_item = ffi.new("int", item)

        setdialog(dialogPointer, c_item)

    end
end

function tuzasfun.IsChatActive()
    samp10 = getModuleHandle('samp.dll')
    samp10 = samp10 + 0x26EB84
    samp10 = readMemory(samp10, 4, false)
    samp10 = samp10 + 0x14E0
    samp10 = readMemory(samp10, 4, false)
    if samp10 == 1 then
        return true
    else
        return false
    end
end

function tuzasfun.IsDialogActive()
    samp10 = getModuleHandle('samp.dll')
    samp10 = samp10 + 0x26EB50
    samp10 = readMemory(samp10, 4, false)
    local dialog_status = samp10 + 0x28
    dialog_status = readMemory(dialog_status, 4, false)
    if dialog_status == 1 then
        local dialog_id = samp10 + 0x30
        dialog_id = readMemory(dialog_id, 4, false)
        return dialog_id
    else
        return false
    end
end
function tuzasfun.SetDialogInput(input, button)
    local samp = getModuleHandle('samp.dll')
    local SAMP_DIALOG_INFO_OFFSET = samp + 0x26EB50
    local pDialog = readMemory(SAMP_DIALOG_INFO_OFFSET, 4, false)
    local pDialogpEditBox = pDialog + 0x24
    local pEditBox = readMemory(pDialogpEditBox, 4, false)
    local CDXUTEditBox = samp + 0x85580
    local SAMP_DIALOG_CLOSE_OFFSET = samp + 0x70630
    local func = ffi.cast('void (__thiscall*)(void *, char *)', CDXUTEditBox)
    if func ~= nil then
        local p1 = ffi.cast('void *', pEditBox)
        local p3 = ffi.new("char[?]", #input + 1)
        ffi.copy(p3, input)
        func(p1, p3)
        local funcc = ffi.cast('void (__thiscall*)(void *, char *)', SAMP_DIALOG_CLOSE_OFFSET)
        local p4 = ffi.cast('void *', pDialog)
        local buttonBuf = ffi.new('char[?]', #button + 1)
        ffi.copy(buttonBuf, button)
        funcc(p4, buttonBuf)

    end
end


function tuzasfun.IsSampTextDrawExist(ID)
    --[[
        0.3.7 - R5
        IsSampTextDrawExist(1000)
    ]]
    local samp10 = getModuleHandle('samp.dll')
    samp10 = samp10 + 0x26EB94
    samp10 = readMemory(samp10, 4, false)
    samp10 = samp10 + 0x3DE
    samp10 = readMemory(samp10, 4, false)
    samp10 = samp10 + 0x1C
    samp10 = readMemory(samp10, 4, false)
    ID = ID * 0x4
    samp10 = samp10 + ID
    local samp9 = readMemory(samp10, 1, false)
    if samp9 then
        return true
    else
        return false
    end
end

function tuzasfun.GetTextDrawText(ID)
    local samp10 = getModuleHandle('samp.dll')
    local SAMP_INFO_OFFSET = samp10 + 0x26EB94
    SAMP_INFO_OFFSET = readMemory(SAMP_INFO_OFFSET, 4, false)
    local SAMP_PPOOLS_OFFSET = SAMP_INFO_OFFSET + 0x3DE
    SAMP_PPOOLS_OFFSET = readMemory(SAMP_PPOOLS_OFFSET, 4, false)
    local SAMP_PPOOL_TEXTDRAW_OFFSET = SAMP_PPOOLS_OFFSET + 0x1C
    SAMP_PPOOL_TEXTDRAW_OFFSET = readMemory(SAMP_PPOOL_TEXTDRAW_OFFSET, 4, false)
    if SAMP_PPOOL_TEXTDRAW_OFFSET > 0 then
        ID = ID * 0x4
        SAMP_PPOOL_TEXTDRAW_OFFSET = SAMP_PPOOL_TEXTDRAW_OFFSET + ID
        local samp9 = readMemory(samp10, 1, false)
        if samp9 then
            local SAMP_TEXTDRAW_STRUCT_OFFSET = SAMP_PPOOL_TEXTDRAW_OFFSET + 0x2400
            SAMP_TEXTDRAW_STRUCT_OFFSET = readMemory(SAMP_TEXTDRAW_STRUCT_OFFSET, 4, false)
            local SAMP_TEXTDRAW_TEXT_OFFSET = SAMP_TEXTDRAW_STRUCT_OFFSET + 0x0
            if SAMP_TEXTDRAW_TEXT_OFFSET > 0 then
                local text = readString(SAMP_TEXTDRAW_TEXT_OFFSET, 1024, 'utf-8')
                if type(text) ~= "boolean" then
                    return text
                end
            end
        else
            return false
        end
    else
        return false
    end

end


function tuzasfun.SendCommand(text)
    --[[
       0.3.7 - R5
        SendCommand('/hello')
    ]]
    local samp10 = getModuleHandle('samp.dll')
    local ADDR_FUNC_SEND_COMMAND = samp10 + 0x69900
    local send = ffi.cast("void (__stdcall*)(char*)", ADDR_FUNC_SEND_COMMAND)
    if send ~= 0 then
        local c_str = ffi.new("char[?]", #text + 1)
        ffi.copy(c_str, text)
        send(c_str)
    end
end

function tuzasfun.GetGameText(id)
    id = id * 0x80
    id = id + 0xBAACC0
    local text_offset = memory.read(id, 1, false)
    if text_offset > 0 then
        writeMemory(id, 0, 0, false)
        local string = readString(id, 1024, 'utf-8')

        return string
    else
        return false
    end
end





function readString(address, size)
    local result = ''
    for i = address, address + size - 1 do
        local char = string.char(readMemory(i, 1))
        if char == '\0' then
            break
        end
        result = result .. char
    end
    return result
end

return tuzasfun