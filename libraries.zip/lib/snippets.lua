require 'lib.moonloader'
local ffi = require("ffi")




function main()
    wait(7500)

   while true do wait(0)
    chat_text, prefix_text, color, prefix_color = getChatString()
local chat_string = ""
for i = 0, 3 do
    chat_string = chat_string .. string.char(bit32.rshift(chat_text, i * 8) % 256)
      ChatMsg("{FFFF00}Textas: "..chat_string)
end
      
wait(900)
           end
end






    function ChatMsg(text)
        --[[]
            ChatMsg("{FFFF00}Hello!")
        --]]
        local samp10 = getModuleHandle('samp.dll')
        local samp_chat_info_offset = samp10 + 0x26EB80
        local ADDR_FUNC_ADD_MSG = samp10 + 0x68070
        local pChat = readMemory(samp_chat_info_offset, 4, false)
        local func = ffi.cast("void(__cdecl *)(void *, char *)", ADDR_FUNC_ADD_MSG)
        if func ~= 0 then
            local chatPointer = ffi.cast("void*", pChat)
            local c_str = ffi.new("char[?]", #text + 1)
            ffi.copy(c_str, text)
            func(chatPointer, c_str)
            end
            return true
        end


function get_samp_version_id()
    local versionid = 0
    samp10 = getModuleHandle('samp.dll')
    samp10 = samp10 + 0x128
    samp9 = readMemory(samp10, 4, true)
    if samp9 == 0x5542F47A then
        versionid = 1 -- r1
    end
    if samp9 == 0x59C30C94 then
        versionid = 2 -- r2
    end
    if samp9 == 0x5542F47A then
        versionid = 3 -- 0.3DL
    end

    samp10 = samp10 - 8
    samp9 = readMemory(samp10, 4, true)
    if samp9 == 0x5C0B4243 then
        versionid = 4 -- r3
    end
    if samp9 == 0x5DD606CD then
        versionid = 5 -- R4
    end
    if samp9 == 0x6094ACAB then
        versionid = 6 -- R4-2
        if samp9 == 0x6372C39E then
            versionid = 7
        end
    end
    return versionid

end

--[[:get_samp_version_id
// 0AB1: @get_samp_version_id 0 _returned: ID 0@  
30@ = 0
IF 0AA2: 31@ = "samp.dll" // IF and SET
THEN
    31@ += 0x128
    0A8D: 29@ = read_memory 31@ size 4 virtual_protect 1
    IF 29@ == 0x5542F47A
    THEN // 0.3.7 R1
        30@ = 1
    END
    
    IF 29@ == 0x59C30C94
    THEN // 0.3.7 R2
        30@ = 2
    END
    
    IF 29@ == 0x5A6A3130
    THEN // 0.3.DL
        30@ = 3
    END
    31@ -= 8 // reading samp.dll + 0x120
    0A8D: 29@ = read_memory 31@ size 4 virtual_protect 1
    IF 29@ == 0x5C0B4243
    THEN // 0.3.7 R3 
        30@ = 4
    END  
    
    IF 29@ == 0x5DD606CD
    THEN // 0.3.7 R4
        30@ = 5
    END
    IF 29@ == 0x6094ACAB
    THEN // 0.3.7 R4 - v2
        30@ = 6
    END 
    IF 29@ == 0x6372C39E
    THEN // 0.3.7 R5
        30@ = 7
    END 
END
0AB2: ret 1 30@]]


function getChatString(chat_text, prefix_text, color, prefix_color)
    local samp_dll = getModuleHandle('samp.dll')
    samp_dll = samp_dll + 0x26EB80
    local chat_info = readMemory(samp_dll, 4, false)
    chat_info = chat_info + 0x132
    local chat_id = 99
    chat_id = chat_id * 0xFC
    chat_info = chat_info + chat_id

    local chat_text = chat_info + 0x20
    local prefix_text = chat_info + 0x4
    local color = readMemory(chat_info + 0xF4, 4, false)
    local prefix_color = readMemory(chat_info + 0xF8, 1, false)
    if prefix_color == 0 then
        prefix_color = 0
    else
        prefix_color = readMemory(chat_info + 0xF8, 4, false)
    end
    return chat_text, prefix_text, color, prefix_color
end


--[[:getChatString
IF 0AA2: 31@ = "samp.dll"
THEN
    31@ += 0x26EB80 // SAMP_CHAT_INFO_OFFSET
    0A8D: 31@ readMem 31@ sz 4 vp 0
    31@ += 0x132
    0@ *= 0xFC
    005A: 31@ += 0@

    0A8E: 30@ = 31@ + 0x20 // CHAT_TEXT_OFFSET

    0A8E: 29@ = 31@ + 0x4 // CHAT_PREFIX_TEXT_OFFSET
    0A8E: 28@ = 31@ + 0xF4 // CHAT_COLOR_OFFSET
    0A8D: 27@ readMem 28@ sz 4 vp 0 // HEX Color
    0A8E: 26@ = 31@ + 0xF8 // CHAT_PREFIX_COLOR_OFFSET
    0A8D: 25@ readMem 26@ sz 1 vp 0
    IF NOT 25@ > 0
    THEN 24@ = 0
    ELSE 0A8D: 24@ readMem 26@ sz 4 vp 0
    END
    0AA3: 31@
END
0AB2: ret 4 30@ 29@ 27@ 24@ ]]